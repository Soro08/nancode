## Appels et passages de paramètres

1- Écrivez l’algorithme suivant :

Écrivez cet algorithme.

Vous pouvez utiliser certaines des fonctions 
def plus_petit():

def plus_grand() :

def puissance_n():

def reutilisation(a, b, c):
    """
    :entrée a: int
    :entrée b: int
    :entrée c: int
    :sortie d: int
    :post-cond: d = xⁿ ou x est le plus petit nombre parmi a, b et c,
                et n est le plus grand nombre parmi a, b et c
    """


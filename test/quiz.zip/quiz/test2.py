# Chiffres romains

# Convertir un petit nombre en chiffres romains :
def romain(n):
    """
    :entrée n: int
    :sortie r: str
    :pré-cond: 0 < n < 4000
    :post-cond: r est le représentation en chiffres romains de n
    """
On rappelle les symboles utilisés pour les chiffres romains :

I	V	X	L	C	D	M
1	5	10	50	100	500	1000
Il pourra être utile d’utiliser la fonction


